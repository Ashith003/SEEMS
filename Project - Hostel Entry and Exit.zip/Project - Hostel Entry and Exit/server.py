import datetime
from find_face import process_images, store_embeddings
import mysql.connector
import os
import csv
from flask import Flask, request, redirect, url_for, render_template, flash, Response, send_from_directory
from werkzeug.utils import secure_filename
import cv2
import numpy as np
from imgbeddings import imgbeddings
from PIL import Image
import psycopg2
import mysql.connector
import warnings
from twilio.rest import Client

app = Flask(__name__)
app.secret_key = 'your_secret_key'

account_sid = 'AC7dea9dc69fd706d517d179d16a68d981'
auth_token = '0633fe8a4b559ea73711f225db521719'
twilio_client = Client(account_sid, auth_token)

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Ashith@1704",
    database="seems"
)
cursor = db.cursor()

# Load the face cascade for face detection
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

warnings.filterwarnings("ignore")

# Loading the Haar cascade file for face detection
alg = "C:/Users/Ashith/PycharmProjects/BACKUP/Project - Hostel Entry and Exit/haarcascade_frontalface_default.xml"
haar_cascade = cv2.CascadeClassifier(alg)

# Database connection (modify as necessary)
conn = psycopg2.connect('postgres://avnadmin:AVNS_q-VA6mAIg2KrcCKdKfs@pg-4bb659c-seams1318-130a.h.aivencloud.com:20039/defaultdb?sslmode=require')
cur = conn.cursor()


@app.route('/')
def index():
    return render_template('index.html')


def clear_old_logs():
    log_file_path = 'C:/Users/Ashith/PycharmProjects/BACKUP/Project - Hostel Entry and Exit/StudentDetails/24hr_log.csv'
    if os.path.exists(log_file_path):
        current_time = datetime.datetime.now()
        updated_rows = []
        with open(log_file_path, mode='r') as file:
            rows = list(csv.reader(file))
            for row in rows:
                log_time = datetime.datetime.strptime(row[1], '%Y-%m-%d %H:%M:%S')
                if (current_time - log_time).total_seconds() < 86400:  # 24 hours in seconds
                    updated_rows.append(row)

        # Write back only the rows that are within the 24-hour window
        with open(log_file_path, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(updated_rows)
        print("Old logs cleared.")


# Function to log detection events5
def log_detection(name, status):
    log_file_path = 'C:/Users/Ashith/PycharmProjects/BACKUP/Project - Hostel Entry and Exit/StudentDetails/24hr_log.csv'
    detection_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(log_file_path, mode='a', newline='') as log_file:
        writer = csv.writer(log_file)
        writer.writerow([name, detection_time, status])
    print(f"Logged {name} as {status}.")


def generate_frames(cap):
    ibed = imgbeddings()
    notified_students = set()
    student_last_status = {}

    # Clear old logs before starting
    clear_old_logs()

    while True:
        success, frame = cap.read()
        if not success:
            break

        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = haar_cascade.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=10, minSize=(100, 100))

        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (192, 192, 192), 1)
            face_roi = frame[y:y + h, x:x + w]
            face_img = Image.fromarray(cv2.cvtColor(face_roi, cv2.COLOR_BGR2RGB))
            embedding = ibed.to_embeddings(face_img)
            embedding_list = embedding[0].tolist()

            embedding_array = np.array(embedding_list)
            embedding_str = "[" + ",".join(str(val) for val in embedding_array) + "]"

            try:
                cur.execute("SELECT picture FROM pictures ORDER BY embedding <-> %s LIMIT 1;", (embedding_str,))
                rows = cur.fetchall()

                if rows:
                    picture_name = rows[0][0]
                    base_name = os.path.splitext(picture_name)[0]
                    full_name = ''.join(filter(str.isalpha, base_name))

                    if full_name:
                        # Display the name on the frame
                        cv2.putText(frame, full_name, (x, y - 10 if y - 10 > 10 else y + 10), cv2.FONT_HERSHEY_SIMPLEX,
                                    0.9, (255, 0, 0), 2)
                        print(f"Detected student: {full_name}")  # Debugging statement

                        current_time = datetime.datetime.now().time()

                        # Determine if the student is leaving or returning
                        if full_name in student_last_status and student_last_status[full_name] == "Outgoing":
                            status = "Incoming"
                        else:
                            status = "Outgoing"

                        last_status = student_last_status.get(full_name)

                        if last_status != status:
                            log_detection(full_name, status)
                            student_last_status[full_name] = status

                        # Handle notifications and additional processing
                        if status == "Outgoing" and current_time >= datetime.time(9, 30):
                            if full_name not in notified_students:
                                # Send notification to warden if needed
                                message = twilio_client.messages.create(
                                    body=f"Student {full_name} did not return before 9:30 PM.",
                                    from_='+19548839408',
                                    to='+917349418669'
                                )
                                print(f"SMS sent to warden: {message.sid}")
                                notified_students.add(full_name)

            except Exception as e:
                print(f"Database query error: {e}")

        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

@app.route('/video_feed_outgoing')
def video_feed_outgoing():
    cap = cv2.VideoCapture('https://192.168.174.32:8080/video')  # Outgoing
    return Response(generate_frames(cap), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/video_feed_incoming')
def video_feed_incoming():
    cap = cv2.VideoCapture('https://192.168.174.247:8080/video')  # Incoming
    return Response(generate_frames(cap), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/recognize')
def recognize():
    return render_template('recognize.html')


@app.route('/train_image', methods=['GET', 'POST'])
def train_image():
    if request.method == 'POST':
        if 'images' not in request.files:
            flash("No images uploaded.", "error")
            return redirect(url_for('train_image'))

        images = request.files.getlist('images')
        training_image_dir = "C:/Users/Ashith/PycharmProjects/BACKUP/Project - Hostel Entry and Exit/TrainingImage"

        if not os.path.exists(training_image_dir):
            os.makedirs(training_image_dir)

        for img in images:
            if img and img.filename:
                filename = secure_filename(img.filename)
                img_path = os.path.join(training_image_dir, filename)
                img.save(img_path)

        flash("Images uploaded successfully!", "success")

        # Call the processing functions after images are uploaded
        process_images()
        store_embeddings()

        return redirect(url_for('train_image'))

    return render_template('training.html')


@app.route('/studentdata')
def student_data():
    return render_template('studentdata.html')


@app.route('/submit_student_data', methods=['POST'])
def submit_student_data():
    std_id = request.form.get('std_id')
    name = request.form.get('name')
    room_number = request.form.get('room_number')
    phone_number = request.form.get('phone_number')
    email = request.form.get('email')
    try:
        cursor.execute(
            "INSERT INTO student_details(student_id,student_name, phone_number, email, room_number ) VALUES (%s, %s, %s, %s, %s)",
            (std_id, name, phone_number, email, room_number)
        )
        db.commit()
        flash("Student data saved successfully!", "success")
    except mysql.connector.Error as err:
        flash(f"Database Error: {err}", "error")
        print(f"Database Error: {err}")  # Print the error to the console for debugging
    return redirect(url_for('student_data'))


@app.route('/changepassword', methods=['GET', 'POST'])
def change_password():
    if request.method == 'POST':
        warden_id = request.form['warden_id']
        old_password = request.form['old-password']
        new_password = request.form['new-password']

        cursor = db.cursor()
        # Check if old password matches
        cursor.execute("SELECT password FROM warden WHERE warden_id = %s", (warden_id,))
        result = cursor.fetchone()
        if result and result[0] == old_password:
            # Update to the new password
            cursor.execute("UPDATE warden SET password = %s WHERE warden_id = %s", (new_password, warden_id))
            db.commit()
            flash('Password successfully changed!', 'success')
            return redirect(url_for('login'))
        else:
            flash('Old password is incorrect.', 'danger')
            return redirect(url_for('change_password'))
        cursor.close()
    return render_template('changepassword.html')


@app.route('/logout')
def logout():
    return render_template('logout.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        warden_id = request.form['war_id']
        username = request.form['username']
        password = request.form['password']
        try:
            cursor.execute("INSERT INTO warden VALUES (%s, %s, %s)", (warden_id, username, password))
            db.commit()
            return redirect(url_for('login'))
        except mysql.connector.Error as err:
            flash(f"Error: {err}")
            return redirect(url_for('signup'))
    return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    error_message = None
    if request.method == 'POST':
        warden_id = request.form['war_id']
        username = request.form['username']
        password = request.form['password']
        cursor.execute("SELECT * FROM warden WHERE warden_id = %s AND username=%s AND password=%s",
                       (warden_id, username, password))
        user = cursor.fetchone()
        if user:
            return redirect(url_for('recognize'))
        else:
            error_message = "Invalid username or password"
    return render_template('login.html')


@app.route('/images/<path:filename>')
def serve_image(filename):
    return send_from_directory('templates', filename)


if __name__ == '__main__':
    app.run(debug=True)
